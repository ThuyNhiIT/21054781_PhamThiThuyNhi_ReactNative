import React from 'react';
import { View, Text, StyleSheet, Image, TouchableOpacity } from 'react-native';

const ProductDetails = () => {
  return (
    <View style={styles.container}>
      <View style={styles.imageContainer}>
         <Image source={{ uri: 'https://cdn-images.vtv.vn/2019/10/10/photo-1-15706463929181755249740.jpg' }}
          style={styles.productImage} 
        />
      </View>
      <View style={styles.detailsContainer}>
        <Text style={styles.productName}>Điện Thoại Vsmart Joy 3 - Hàng chính hãng</Text>
        <View style={styles.ratingContainer}>
          <Text style={styles.rating}>★★★★★</Text>
          <Text style={styles.ratingText}>(Xem 828 đánh giá)</Text>
        </View>
        <Text style={styles.price}>1.790.000 ₫</Text>
        <Text style={styles.originalPrice}>1.790.000 ₫</Text>
        <TouchableOpacity style={styles.guaranteeButton}>
          <Text style={styles.guaranteeText}>Ở ĐÂU RẺ HƠN HOÀN TIỀN?</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.colorButton}>
          <Text style={styles.colorText}>4 MÀU-CHỌN MÀU</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.buyButton}>
          <Text style={styles.buyText}>CHỌN MUA</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    padding: 16,
  },
  imageContainer: {
    alignItems: 'center',
    marginBottom: 16,
  },
  productImage: {
    width: 200,
    height: 200,
  },
  detailsContainer: {
    
  },
  productName: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  ratingContainer: {
    flexDirection: ' row',
    alignItems: 'center',
    marginBottom: 8,
  },
  rating: {
    fontSize: 16,
    color: '#FFD700',
  },
  ratingText: {
    fontSize: 14,
    marginLeft: 4,
  },
  price: {
    fontSize: 20,
    color: '#FF0000',
    fontWeight: 'bold',
    marginBottom: 4,
  },
  originalPrice: {
    fontSize: 16,
    textDecorationLine: 'line-through',
    color: '#888',
    marginBottom: 16,
  },
  guaranteeButton: {
    backgroundColor: '#f0c14b',
    padding: 10,
    borderRadius: 5,
    alignItems: 'center',
    marginBottom: 8,
  },
  guaranteeText: {
    fontSize: 14,
    fontWeight: 'bold',
  },
  colorButton: {
    backgroundColor: '#f0c14b',
    padding: 10,
    borderRadius: 5,
    alignItems: 'center',
    marginBottom: 8,
  },
  colorText: {
    fontSize: 14,
    fontWeight: 'bold',
  },
  buyButton: {
    backgroundColor: '#28a745',
    padding: 10,
    borderRadius: 5,
    alignItems: 'center',
  },
  buyText: {
    fontSize: 16,
    color: '#fff',
    fontWeight: 'bold',
  },
});

export default ProductDetails;