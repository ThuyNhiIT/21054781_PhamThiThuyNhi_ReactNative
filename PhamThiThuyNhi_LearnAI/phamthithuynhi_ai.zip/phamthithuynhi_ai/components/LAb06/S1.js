import React, { useState } from 'react';
import { View, Text, StyleSheet, Image, TouchableOpacity, TextInput } from 'react-native';

const App = () => {
  const [quantity, setQuantity] = useState(1);
  const [discountCode, setDiscountCode] = useState('');

  const handleQuantityChange = (value) => {
    setQuantity(value);
  };

  const handleDiscountCodeChange = (text) => {
    setDiscountCode(text);
  };

  const handleApplyDiscount = () => {
    // TODO: Implement discount logic
    console.log('Apply discount with code:', discountCode);
  };

  const handleCheckout = () => {
    // TODO: Implement checkout logic
    console.log('Checkout with quantity:', quantity);
  };

  return (
    <View style={styles.container}>
      <View style={styles.product}>
         <Image source={{ uri: 'https://inkythuatso.com/uploads/thumbnails/800/2023/03/1-hinh-anh-ngay-moi-hanh-phuc-sieu-cute-inkythuatso-09-13-35-50.jpg' }}
          style={styles.productImage}
        />
        <View style={styles.productInfo}>
          <Text style={styles.productName}>
            Nguyên hàm tích phân và ứng dụng
          </Text>
          <Text style={styles.productSupplier}>
            Cung cấp bởi Tiki Trading
          </Text>
          <Text style={styles.productPrice}>141.800 ₫</Text>
          <Text style={styles.productOriginalPrice}>141.000 ₫</Text>
          <View style={styles.quantityControl}>
            <TouchableOpacity
              onPress={() => handleQuantityChange(quantity - 1)}
              disabled={quantity === 1}
            >
              <Text style={styles.quantityButton}>-</Text>
            </TouchableOpacity>
            <Text style={styles.quantityValue}>{quantity}</Text>
            <TouchableOpacity onPress={() => handleQuantityChange(quantity + 1)}>
              <Text style={styles.quantityButton}>+</Text>
            </TouchableOpacity>
          </View>
          <TouchableOpacity style={styles.buyButton} onPress={() => handleCheckout()}>
            <Text style={styles.buyButtonText}>Mua sau</Text>
          </TouchableOpacity>
        </View>
      </View>
      <View style={styles.discount}> <Text style={styles.discountLabel}>Mã giảm giá:</Text>
        <TextInput
          style={styles.discountInput}
          value={discountCode}
          onChangeText={handleDiscountCodeChange}
          placeholder="Nhập mã giảm giá"
        />
        <TouchableOpacity style={styles.applyButton} onPress={handleApplyDiscount}>
          <Text style={styles.applyButtonText}>Áp dụng</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: '#fff',
  },
  product: {
    flexDirection: 'row',
    marginBottom: 20,
  },
  productImage: {
    width: 100,
    height: 150,
    marginRight: 20,
  },
  productInfo: {
    flex: 1,
  },
  productName: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  productSupplier: {
    fontSize: 14,
    color: '#666',
  },
  productPrice: {
    fontSize: 16,
    color: '#e91e63',
  },
  productOriginalPrice: {
    fontSize: 14,
    textDecorationLine: 'line-through',
    color: '#999',
  },
  quantityControl: {
    flexDirection: 'row',
    alignItems: 'center',
    marginVertical: 10,
  },
  quantityButton: {
    fontSize: 20,
    padding: 10,
  },
  quantityValue: {
    fontSize: 16,
    marginHorizontal: 10,
  },
  buyButton: {
    backgroundColor: '#4caf50',
    padding: 10,
    alignItems: 'center',
  },
  buyButtonText: {
    color: '#fff',
    fontSize: 16,
  },
  discount: {
    marginTop: 20,
  },
  discountLabel: {
    fontSize: 16,
    marginBottom: 10,
  },
  discountInput: {
    borderWidth: 1,
    borderColor: '#ccc',
    padding: 10,
    marginBottom: 10,
  },
  applyButton: {
    backgroundColor: '#2196f3',
    padding: 10,
    alignItems: 'center',
  },
  applyButtonText: {
    color: '#fff',
    fontSize: 16,
  },
});

export default App;