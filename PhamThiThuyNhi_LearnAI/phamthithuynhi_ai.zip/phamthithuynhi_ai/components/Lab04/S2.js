import React from 'react';
import {
  View,
  Text,
  Image,
  FlatList,
  StyleSheet,
  TouchableOpacity,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';

const products = [
  {
    id: '1',
    name: 'Cáp chuyển từ Cổng USB sang PS2...',
    price: '69.900 đ',
    rating: 4.5,
    reviews: 15,
    discount: '-39%',
    image: 'https://inkythuatso.com/uploads/thumbnails/800/2023/03/1-hinh-anh-ngay-moi-hanh-phuc-sieu-cute-inkythuatso-09-13-35-50.jpg',
  },
  {
    id: '2',
    name: 'Cáp chuyển từ Cổng USB sang PS2...',
    price: '69.900 đ',
    rating: 4.5,
    reviews: 15,
    discount: '-39%',
    image: 'https://inkythuatso.com/uploads/thumbnails/800/2023/03/1-hinh-anh-ngay-moi-hanh-phuc-sieu-cute-inkythuatso-09-13-35-50.jpg',
  },
  {
    id: '3',
    name: 'Cáp chuyển từ Cổng USB sang PS2...',
    price: '69.900 đ',
    rating: 4.5,
    reviews: 15,
    discount: '-39%',
    image: 'https://inkythuatso.com/uploads/thumbnails/800/2023/03/1-hinh-anh-ngay-moi-hanh-phuc-sieu-cute-inkythuatso-09-13-35-50.jpg',
  },
  {
    id: '4',
    name: 'Cáp chuyển từ Cổng USB sang PS2...',
    price: '69.900 đ',
    rating: 4.5,
    reviews: 15,
    discount: '-39%',
    image: 'https://inkythuatso.com/uploads/thumbnails/800/2023/03/1-hinh-anh-ngay-moi-hanh-phuc-sieu-cute-inkythuatso-09-13-35-50.jpg',
  },
  {
    id: '5',
    name: 'Cáp chuyển từ Cổng USB sang PS2...',
    price: '69.900 đ',
    rating: 4.5,
    reviews: 15,
    discount: '-39%',
    image: 'https://inkythuatso.com/uploads/thumbnails/800/2023/03/1-hinh-anh-ngay-moi-hanh-phuc-sieu-cute-inkythuatso-09-13-35-50.jpg',
  },
  {
    id: '6',
    name: 'Cáp chuyển từ Cổng USB sang PS2...',
    price: '69.900 đ',
    rating: 4.5,
    reviews: 15,
    discount: '-39%',
    image: 'https://inkythuatso.com/uploads/thumbnails/800/2023/03/1-hinh-anh-ngay-moi-hanh-phuc-sieu-cute-inkythuatso-09-13-35-50.jpg',
  },
  // Thêm các sản phẩm khác ở đây
];

export default function ProductGrid() {
  const renderProduct = ({ item }) => (
    <View style={styles.productContainer}>
      <Image source={{ uri: item.image }} style={styles.productImage} />
      <Text style={styles.productName} numberOfLines={2}>
        {item.name}
      </Text>
      <View style={styles.ratingContainer}>
        <Ionicons name="star" size={16} color="gold" />
        <Ionicons name="star" size={16} color="gold" />
        <Ionicons name="star" size={16} color="gold" />
        <Ionicons name="star" size={16} color="gold" />
        <Ionicons name="star-half" size={16} color="gold" />
        <Text style={styles.reviewText}>({item.reviews})</Text>
      </View>
      <Text style={styles.productPrice}>{item.price}</Text>
      <Text style={styles.productDiscount}>{item.discount}</Text>
    </View>
  );

  return (
    <View style={styles.container}>
      <FlatList
        data={products}
        renderItem={renderProduct}
        keyExtractor={(item) => item.id}
        numColumns={2}
        contentContainerStyle={styles.list}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F5F5F5',
    padding: 10,
  },
  list: {
    paddingBottom: 20,
  },
  productContainer: {
    flex: 1,
    backgroundColor: 'white',
    margin: 5,
    borderRadius: 10,
    padding: 10,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  productImage: {
    width: '100%',
    height: 100,
    borderRadius: 10,
    marginBottom: 10,
  },
  productName: {
    fontSize: 14,
    fontWeight: 'bold',
    marginBottom: 5,
  },
  ratingContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 5,
  },
  reviewText: {
    fontSize: 12,
    color: 'gray',
    marginLeft: 5,
  },
  productPrice: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
  },
  productDiscount: {
    fontSize: 12,
    color: 'red',
    marginTop: 5,
  },
});
