import React, { useState } from 'react';
import { View, Text, StyleSheet, Image, TouchableOpacity, FlatList } from 'react-native';

const bikes = [
  {
    id: '1',
    name: 'Pinarello',
    price: 1800,
    image: 'https://inkythuatso.com/uploads/thumbnails/800/2023/03/1-hinh-anh-ngay-moi-hanh-phuc-sieu-cute-inkythuatso-09-13-35-50.jpg',
  },
  {
    id: '2',
    name: 'Pina Mountain',
    price: 1700,
    image: 'https://cdn.mobilecity.vn/mobilecity-vn/images/2024/04/hinh-nen-doremon-cho-dien-thoai-an-banh.jpg.webp',
  },
  {
    id: '3',
    name: 'Pina Bike',
    price: 1500,
    image: 'https://inkythuatso.com/uploads/thumbnails/800/2023/03/1-hinh-anh-ngay-moi-hanh-phuc-sieu-cute-inkythuatso-09-13-35-50.jpg',
  },
  {
    id: '4',
    name: 'Pinarello',
    price: 1900,
    image: 'https://cdn.mobilecity.vn/mobilecity-vn/images/2024/04/hinh-nen-doremon-cho-dien-thoai-an-banh.jpg.webp',
  },
  {
    id: '5',
    name: 'Pinarello',
    price: 2700,
    image: 'https://inkythuatso.com/uploads/thumbnails/800/2023/03/1-hinh-anh-ngay-moi-hanh-phuc-sieu-cute-inkythuatso-09-13-35-50.jpg',
  },
  {
    id: '6',
    name: 'Pinarello',
    price: 1350,
    image: 'https://inkythuatso.com/uploads/thumbnails/800/2023/03/1-hinh-anh-ngay-moi-hanh-phuc-sieu-cute-inkythuatso-09-13-35-50.jpg',
  },
];

const App = () => {
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [filteredBikes, setFilteredBikes] = useState(bikes);

  const handleCategoryChange = (category) => {
    setSelectedCategory(category);
    if (category === 'All') {
      setFilteredBikes(bikes);
    } else {
      const filtered = bikes.filter((bike) => bike.name.includes(category));
      setFilteredBikes(filtered);
    }
  };

  const renderItem = ({ item }) => (
    <View style={styles.bikeItem}>
      <Image source={{ uri: item.image }} style={styles.bikeImage} />
      <Text style={styles.bikeName}>{item.name}</Text>
      <Text style={styles.bikePrice}>${item.price}</Text>
    </View>
  );

  return (
    <View style={styles.container}>
      <Text style={styles.title}>The world's Best Bike</Text>
      <View style={styles.categories}>
        <TouchableOpacity
          onPress={() => handleCategoryChange('All')}
          style={[
            styles.categoryButton,
            selectedCategory === 'All' && styles.selectedCategory,
          ]}
        >
          <Text style={styles.categoryButtonText}>All</Text>
        </TouchableOpacity>
        <TouchableOpacity
          onPress={() => handleCategoryChange('Pinarello')}
          style={[
            styles.categoryButton,
            selectedCategory === 'Pinarello' && styles.selectedCategory,
          ]}
        >
          <Text style={styles.categoryButtonText}>Pinarello</Text>
        </TouchableOpacity>
        <TouchableOpacity
          onPress={() => handleCategoryChange('Pina')}
          style={[
            styles.categoryButton,
            selectedCategory === 'Pina' && styles.selectedCategory,
          ]}
        >
          <Text style={styles.categoryButtonText}>Pina</Text>
        </TouchableOpacity>
      </View>
      <FlatList
        data={filteredBikes}
        renderItem={renderItem}
        keyExtractor={(item) => item.id}
        numColumns={2}
        contentContainerStyle={styles.bikeList}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: '#fff',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 20,
  },
  categories: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    marginBottom: 20,
  },
  categoryButton: {
    padding: 10,
    backgroundColor: '#f0f0f0',
    borderRadius: 5,
  },
  selectedCategory: {
    backgroundColor: '#d0d0d0',
  },
  categoryButtonText: {
    fontSize: 16,
  },
  bikeList: {
    paddingBottom: 20,
  },
  bikeItem: {
    flex: 1,
    margin: 5,
    backgroundColor: '#fff',
    borderRadius: 10,
    padding: 10,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  bikeImage: {
    width: 100,
    height: 100,
    marginBottom: 10,
  },
  bikeName: {
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  bikePrice: {
    fontSize: 16,
    color: '#888',
  },
});

export default App;
