import { Text, SafeAreaView, StyleSheet } from 'react-native';

import L5_S2 from './components/Lab05/S2';
import L6_S1 from './components/LAb06/S1';
import L4_S1 from './components/Lab04/S1';
import L4_S2 from './components/Lab04/S2';
import L3_S1 from './components/Lab03/S1';
import Xe1 from './components/XeDap/S1';
import Xe2 from './components/XeDap/S2';
import Xe3 from './components/XeDap/S3';

export default function App() {
  return (
    //  <L5_S2/>
    // <L6_S1/>
    // <L4_S1/>
    // <L4_S2/>
    // <L3_S1 />
        <Xe1/>
    // <Xe2 />
    // <Xe3 />

  );
}
